# Cloud-Web-App
Creating a cloud web application to recognize video from a raspberry Pi cluster
